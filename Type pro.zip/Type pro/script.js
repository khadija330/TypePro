
"use strict";

/* =========================================
   TYPEPRO - TYPING MASTERY ACADEMY
   HTML + CSS + Vanilla JavaScript
========================================= */

const $ = id => document.getElementById(id);

const STORAGE_KEY = "typepro_academy_v1";

const defaultData = {
    profile: null,
    completedLevels: [],
    history: [],
    bestWpm: 0,
    totalTests: 0,
    totalMinutes: 0,
    dailyGoal: 15,
    testDuration: 60,
    streak: 0,
    lastVisit: "",
    certificateUnlocked: false
};

let data = loadData();
let currentPage = "home";
let testRunning = false;
let timerInterval = null;
let remainingTime = 60;
let startTime = 0;
let typedCharacters = 0;
let correctCharacters = 0;
let currentText = "";
let activeLevel = null;
let currentLevelText = "";

/* =========================================
   STORAGE
========================================= */

function loadData() {
    try {
        const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
        return saved ? { ...defaultData, ...saved } : { ...defaultData };
    } catch {
        return { ...defaultData };
    }
}

function saveData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function today() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function updateStreak() {
    const current = today();

    if (data.lastVisit === current) return;

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    const previous = [
        yesterday.getFullYear(),
        String(yesterday.getMonth() + 1).padStart(2, "0"),
        String(yesterday.getDate()).padStart(2, "0")
    ].join("-");

    data.streak = data.lastVisit === previous
        ? data.streak + 1
        : 1;

    data.lastVisit = current;
    saveData();
}

/* =========================================
   UTILITIES
========================================= */

function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(showToast.timeout);
    showToast.timeout = setTimeout(() => {
        toast.classList.remove("show");
    }, 3000);
}

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

function getCompleted() {
    return data.completedLevels.length;
}

function getAverageAccuracy() {
    if (!data.history.length) return 0;

    const total = data.history.reduce(
        (sum, item) => sum + item.accuracy, 0
    );

    return Math.round(total / data.history.length);
}

function getCurrentLevel() {
    return Math.min(getCompleted() + 1, 100);
}

/* =========================================
   REGISTRATION AND PROFILE
========================================= */

function initializeApp() {
    if (data.profile) {
        showApplication();
    } else {
        $("welcomeScreen").classList.remove("hidden");
        $("app").classList.add("hidden");
    }
}

$("registrationForm").addEventListener("submit", event => {
    event.preventDefault();

    const name = $("userName").value.trim();
    const age = Number($("userAge").value);

    if (!name || name.length < 2) {
        $("registerError").textContent =
            "Please enter a valid full name.";
        return;
    }

    if (!Number.isInteger(age) || age < 1 || age > 120) {
        $("registerError").textContent =
            "Please enter a valid age between 1 and 120.";
        return;
    }

    data.profile = { name, age };
    updateStreak();
    saveData();
    showApplication();
    showToast("Welcome to TYPEPRO, " + name + "!");
});

function showApplication() {
    $("welcomeScreen").classList.add("hidden");
    $("app").classList.remove("hidden");

    updateStreak();

    $("sidebarName").textContent = data.profile.name;
    $("sidebarAvatar").textContent = data.profile.name[0].toUpperCase();
    $("topAvatar").textContent = data.profile.name[0].toUpperCase();
    $("profileAvatar").textContent = data.profile.name[0].toUpperCase();

    $("profileName").value = data.profile.name;
    $("profileAge").value = data.profile.age;
    $("certificateName").value = data.profile.name;

    $("greeting").textContent = "Welcome Back, " + data.profile.name + "!";

    $("streakTop").textContent = data.streak;

    renderAll();
}

/* =========================================
   NAVIGATION
========================================= */

const pageTitles = {
    home: "Dashboard",
    learn: "Learn Typing",
    hands: "Hand Position Guide",
    videos: "Video Tutorials",
    practice: "Practice Typing",
    levels: "100 Typing Levels",
    progress: "My Progress",
    achievements: "Achievements",
    certificates: "Certificates",
    profile: "My Profile",
    settings: "Settings"
};

function navigate(page) {
    if (!$(page)) return;

    currentPage = page;

    document.querySelectorAll(".page").forEach(section => {
        section.classList.remove("active-page");
    });

    $(page).classList.add("active-page");

    document.querySelectorAll(".nav-item").forEach(button => {
        button.classList.toggle(
            "active",
            button.dataset.page === page
        );
    });

    $("pageHeading").textContent = pageTitles[page] || "TYPEPRO";

    $("sidebar").classList.remove("open");

    if (page === "home") renderDashboard();
    if (page === "progress") renderProgress();
    if (page === "levels") renderLevels();
    if (page === "achievements") renderAchievements();
    if (page === "certificates") renderCertificates();
}

document.querySelectorAll(".nav-item").forEach(button => {
    button.addEventListener("click", () => {
        navigate(button.dataset.page);
    });
});

document.querySelectorAll("[data-go]").forEach(button => {
    button.addEventListener("click", () => {
        navigate(button.dataset.go);
    });
});

$("mobileMenu").addEventListener("click", () => {
    $("sidebar").classList.toggle("open");
});

document.addEventListener("click", event => {
    if (
        window.innerWidth <= 760 &&
        !$("sidebar").contains(event.target) &&
        !$("mobileMenu").contains(event.target)
    ) {
        $("sidebar").classList.remove("open");
    }
});

/* =========================================
   DASHBOARD
========================================= */

function renderDashboard() {
    const completed = getCompleted();
    const progress = completed;

    $("statLevel").textContent = getCurrentLevel();
    $("statWpm").textContent = data.bestWpm;
    $("statAccuracy").textContent = getAverageAccuracy();
    $("statCompleted").textContent = completed;

    $("progressPercent").textContent = progress + "%";
    $("mainProgress").style.width = progress + "%";

    $("streakTop").textContent = data.streak;

    const dailyMinutes = data.history
        .filter(item => item.date === today())
        .reduce((sum, item) => sum + item.minutes, 0);

    const dailyPercent = Math.min(
        100,
        dailyMinutes / data.dailyGoal * 100
    );

    $("goalValue").textContent = Math.round(dailyMinutes);
    $("goalCircle").style.background =
        `conic-gradient(var(--primary) ${dailyPercent * 3.6}deg, #eeeef5 0deg)`;

    renderChart();
}

function renderChart() {
    const chart = $("performanceChart");

    chart.innerHTML = "";

    const recent = data.history.slice(-7);

    const values = Array(7).fill(0);
    recent.forEach((item, index) => {
        values[7 - recent.length + index] = item.wpm;
    });

    const max = Math.max(...values, 10);

    values.forEach((value, index) => {
        const column = document.createElement("div");
        column.className = "bar-column";

        const height = value
            ? Math.max(5, value / max * 100)
            : 3;

        column.innerHTML = `
            <div class="bar" style="height:${height}%"></div>
            <span>${value || "—"}</span>
            <small>${index + 1}</small>
        `;

        chart.appendChild(column);
    });
}

/* =========================================
   LEARNING LESSONS
========================================= */

const lessons = [
    {
        title: "Introduction to Touch Typing",
        icon: "⌨️",
        description: "Discover the foundation of professional typing.",
        paragraphs: [
            "Touch typing is a technique that allows you to type without looking at the keyboard.",
            "It is important because it improves speed, accuracy, productivity and concentration.",
            "Looking at the keyboard repeatedly slows down your typing. Train your fingers to remember the location of each key.",
            "Start slowly and focus on correct finger placement. Speed will develop through consistent practice."
        ]
    },
    {
        title: "Correct Sitting Posture",
        icon: "🪑",
        description: "Learn how to sit comfortably while typing.",
        paragraphs: [
            "Keep your back straight and your shoulders relaxed.",
            "Place your feet comfortably on the floor. Adjust your chair so your elbows are approximately at a right angle.",
            "Keep your wrists in a neutral position rather than bending them sharply.",
            "Position the screen at a comfortable distance, approximately an arm's length away."
        ]
    },
    {
        title: "Keyboard Familiarization",
        icon: "🔤",
        description: "Understand the different keys on a keyboard.",
        paragraphs: [
            "Alphabet keys are used for typing letters.",
            "Number keys are used for entering numbers and symbols.",
            "Enter moves to a new line or confirms an action.",
            "Shift creates capital letters and alternate symbols.",
            "Backspace deletes characters before the cursor.",
            "Spacebar inserts spaces. Tab moves to another field or creates indentation.",
            "Caps Lock toggles uppercase typing. Arrow keys move the cursor.",
            "Function keys F1 to F12 provide special shortcuts depending on the software."
        ]
    },
    {
        title: "Home Row Keys",
        icon: "🏠",
        description: "Master A, S, D, F and J, K, L, ;",
        paragraphs: [
            "The home row is the middle row of the keyboard.",
            "Place your left little, ring, middle and index fingers on A, S, D and F.",
            "Place your right index, middle, ring and little fingers on J, K, L and semicolon.",
            "Most keyboards have small raised marks on F and J. Use these marks to find the correct position without looking.",
            "Return your fingers to the home row after pressing other keys."
        ]
    },
    {
        title: "Finger Placement Guide",
        icon: "✋",
        description: "Learn the correct finger for each keyboard key.",
        paragraphs: [
            "Left little finger: A, Q, Z.",
            "Left ring finger: S, W, X.",
            "Left middle finger: D, E, C.",
            "Left index finger: F, R, T, G, V, B.",
            "Right index finger: J, U, Y, H, N, M.",
            "Right middle finger: K, I and comma.",
            "Right ring finger: L, O and period.",
            "Right little finger: semicolon, P and nearby right-side keys.",
            "Both thumbs are used for the spacebar."
        ]
    }
];

function renderLessons() {
    const container = $("lessonList");
    container.innerHTML = "";

    lessons.forEach((lesson, index) => {
        const card = document.createElement("article");
        card.className = "lesson-card";

        card.innerHTML = `
            <div class="lesson-number">${lesson.icon}</div>
            <h3>Lesson ${index + 1}: ${lesson.title}</h3>
            <p>${lesson.description}</p>
            <button class="secondary-btn" data-lesson="${index}">
                Start Lesson →
            </button>
        `;

        container.appendChild(card);
    });

    container.querySelectorAll("[data-lesson]").forEach(button => {
        button.addEventListener("click", () => {
            showLesson(Number(button.dataset.lesson));
        });
    });
}

function showLesson(index) {
    const lesson = lessons[index];
    const detail = $("lessonDetail");

    detail.innerHTML = `
        <span class="eyebrow">LESSON ${index + 1}</span>
        <h2>${lesson.icon} ${lesson.title}</h2>
        ${lesson.paragraphs.map(p => `<p>${p}</p>`).join("")}
        <button class="primary-btn" id="lessonComplete">
            Mark Lesson as Read ✓
        </button>
    `;

    $("lessonComplete").addEventListener("click", () => {
        showToast("Great! Keep learning and practicing.");
        $("lessonComplete").textContent = "Lesson Reviewed ✓";
        $("lessonComplete").disabled = true;
    });

    detail.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/* =========================================
   INTERACTIVE KEYBOARD
========================================= */

const keyboardRows = [
    ["Q","W","E","R","T","Y","U","I","O","P"],
    ["A","S","D","F","G","H","J","K","L",";"],
    ["Z","X","C","V","B","N","M",",",".","/"]
];

const fingerMap = {
    A:"little", Q:"little", Z:"little",
    S:"ring", W:"ring", X:"ring",
    D:"middle", E:"middle", C:"middle",
    F:"index", R:"index", T:"index",
    G:"index", V:"index", B:"index",
    J:"index", U:"index", Y:"index",
    H:"index", N:"index", M:"index",
    K:"middle", I:"middle", ",":"middle",
    L:"ring", O:"ring", ".":"ring",
    ";":"little", P:"little", "/":"little"
};

const fingerData = {
    "Left Little": {
        keys: ["A","Q","Z"],
        description: "Use your left little finger for A, Q and Z."
    },
    "Left Ring": {
        keys: ["S","W","X"],
        description: "Use your left ring finger for S, W and X."
    },
    "Left Middle": {
        keys: ["D","E","C"],
        description: "Use your left middle finger for D, E and C."
    },
    "Left Index": {
        keys: ["F","R","T","G","V","B"],
        description: "Use your left index finger for F, R, T, G, V and B."
    },
    "Right Index": {
        keys: ["J","U","Y","H","N","M"],
        description: "Use your right index finger for J, U, Y, H, N and M."
    },
    "Right Middle": {
        keys: ["K","I",","],
        description: "Use your right middle finger for K, I and comma."
    },
    "Right Ring": {
        keys: ["L","O","."],
        description: "Use your right ring finger for L, O and period."
    },
    "Right Little": {
        keys: [";","P","/"],
        description: "Use your right little finger for semicolon, P and slash."
    },
    "Thumbs": {
        keys: ["SPACE"],
        description: "Both thumbs can press the spacebar."
    }
};

function renderKeyboard() {
    const keyboard = $("keyboard");
    keyboard.innerHTML = "";

    keyboardRows.forEach(row => {
        const rowElement = document.createElement("div");
        rowElement.className = "key-row";

        row.forEach(key => {
            const keyElement = document.createElement("button");
            keyElement.className = "key " + (fingerMap[key] || "");
            keyElement.textContent = key;
            keyElement.dataset.key = key;

            keyElement.addEventListener("click", () => {
                selectKeyboardKey(key);
            });

            rowElement.appendChild(keyElement);
        });

        keyboard.appendChild(rowElement);
    });

    const spaceRow = document.createElement("div");
    spaceRow.className = "key-row";

    const space = document.createElement("button");
    space.className = "key space thumb";
    space.textContent = "SPACEBAR";
    space.dataset.key = "SPACE";

    space.addEventListener("click", () => selectKeyboardKey("SPACE"));

    spaceRow.appendChild(space);
    keyboard.appendChild(spaceRow);
}

function selectKeyboardKey(key) {
    document.querySelectorAll(".key").forEach(element => {
        element.classList.remove("selected");
    });

    const selected = document.querySelector(`[data-key="${key}"]`);
    if (selected) selected.classList.add("selected");

    const finger = key === "SPACE"
        ? "Thumbs"
        : Object.keys(fingerData).find(name =>
            fingerData[name].keys.includes(key)
        );

    if (finger) {
        selectFinger(finger);
    }
}

function renderFingerButtons() {
    const container = $("fingerButtons");
    container.innerHTML = "";

    Object.keys(fingerData).forEach(finger => {
        const button = document.createElement("button");
        button.textContent = finger;

        button.addEventListener("click", () => {
            selectFinger(finger);
        });

        container.appendChild(button);
    });
}

function selectFinger(finger) {
    const info = fingerData[finger];
    if (!info) return;

    document.querySelectorAll(".key").forEach(key => {
        key.classList.remove("selected");
    });

    info.keys.forEach(key => {
        const element = document.querySelector(`[data-key="${key}"]`);
        if (element) element.classList.add("selected");
    });

    $("fingerInfo").innerHTML = `
        <strong>${finger}</strong><br>
        ${info.description}<br>
        <strong>Keys:</strong> ${info.keys.join(", ")}
    `;
}

const handExercises = [
    { key: "A", finger: "Left Little" },
    { key: "S", finger: "Left Ring" },
    { key: "D", finger: "Left Middle" },
    { key: "F", finger: "Left Index" },
    { key: "J", finger: "Right Index" },
    { key: "K", finger: "Right Middle" },
    { key: "L", finger: "Right Ring" },
    { key: ";", finger: "Right Little" }
];

let handExerciseIndex = 0;

$("handExercise").addEventListener("click", () => {
    handExerciseIndex = 0;
    askHandExercise();
});

function askHandExercise() {
    const exercise = handExercises[handExerciseIndex];

    if (!exercise) {
        $("handExerciseArea").innerHTML =
            "<p class='success'>Excellent! You completed the home row exercise. 🎉</p>";
        return;
    }

    $("handExerciseArea").innerHTML = `
        <div class="finger-info">
            <h3>Place your finger!</h3>
            <p>Which finger should press <strong>${exercise.key}</strong>?</p>
            <input id="handAnswer" placeholder="Enter finger name">
            <button class="primary-btn" id="checkHandAnswer">Check Answer</button>
            <p id="handFeedback"></p>
        </div>
    `;

    $("checkHandAnswer").addEventListener("click", () => {
        const answer = $("handAnswer").value.trim().toLowerCase();

        if (answer === exercise.finger.toLowerCase()) {
            $("handFeedback").textContent = "Correct! Well done.";
            $("handFeedback").className = "success";
            handExerciseIndex++;
            setTimeout(askHandExercise, 700);
        } else {
            $("handFeedback").textContent =
                "Try again! Hint: " + exercise.finger;
            $("handFeedback").className = "error";
        }
    });
}

/* =========================================
   VIDEO TUTORIALS
========================================= */

const videos = [
    ["Introduction to Touch Typing","⌨️","Learn what touch typing means."],
    ["Correct Sitting Posture","🪑","Develop healthy typing habits."],
    ["How to Place Your Fingers","✋","Understand finger positioning."],
    ["Understanding Home Row Keys","🏠","Master the central keyboard row."],
    ["How to Use All Ten Fingers","🤲","Train both hands together."],
    ["Typing Without Looking","👀","Improve keyboard familiarity."],
    ["Improving Typing Accuracy","🎯","Reduce mistakes and build confidence."],
    ["Increasing Typing Speed","⚡","Build speed gradually."],
    ["Common Typing Mistakes","⚠️","Recognize and correct common errors."],
    ["Professional Typing Techniques","🏆","Develop professional typing habits."]
];

function renderVideos() {
    const grid = $("videoGrid");
    grid.innerHTML = "";

    videos.forEach((video, index) => {
        const card = document.createElement("article");
        card.className = "video-card";

        card.innerHTML = `
            <div class="video-thumb">${video[1]}</div>
            <div class="video-card-content">
                <h3>${index + 1}. ${video[0]}</h3>
                <p>${video[2]}</p>
                <button class="secondary-btn" data-video="${index}">
                    Find Video ▶
                </button>
            </div>
        `;

        grid.appendChild(card);
    });

    grid.querySelectorAll("[data-video]").forEach(button => {
        button.addEventListener("click", () => {
            const video = videos[Number(button.dataset.video)];

            const url = "https://www.youtube.com/results?search_query=" +
                encodeURIComponent(video[0] + " typing tutorial");

            window.open(url, "_blank", "noopener,noreferrer");
        });
    });
}

/* =========================================
   TYPING PRACTICE ENGINE
========================================= */

const practiceTexts = [
    "The best way to improve typing is to practice every single day. Start slowly and focus on accuracy before increasing your speed.",
    "A professional typist uses all ten fingers and keeps the hands relaxed. The eyes should remain on the screen instead of the keyboard.",
    "Learning something new requires patience and consistency. Small improvements every day can create excellent results over time.",
    "Technology makes our lives easier. Good typing skills help students, professionals and creators communicate more effectively.",
    "Practice makes progress. Stay focused, maintain correct posture and allow your fingers to become familiar with every key."
];

function prepareText(text) {
    currentText = text;
    $("typingText").innerHTML = "";

    [...text].forEach((character, index) => {
        const span = document.createElement("span");
        span.textContent = character;
        if (index === 0) span.classList.add("current");
        $("typingText").appendChild(span);
    });
}

function startTypingTest(level = null) {
    if (testRunning) return;

    activeLevel = level;
    currentLevelText = "";

    if (level !== null) {
        currentLevelText = getLevelText(level);
        prepareText(currentLevelText);
    } else {
        prepareText(
            practiceTexts[Math.floor(Math.random() * practiceTexts.length)]
        );
    }

    $("testResult").innerHTML = "";
    $("typingInput").value = "";
    $("typingInput").disabled = false;
    $("typingInput").focus();

    typedCharacters = 0;
    correctCharacters = 0;
    remainingTime = Number(data.testDuration) || 60;

    $("timer").textContent = remainingTime;
    $("liveWpm").textContent = 0;
    $("liveAccuracy").textContent = 100;

    testRunning = true;
    startTime = Date.now();

    $("startTest").disabled = true;
    $("startTest").textContent = "Test Running...";

    timerInterval = setInterval(() => {
        remainingTime--;
        $("timer").textContent = remainingTime;

        updateLiveStats();

        if (remainingTime <= 0) {
            finishTypingTest();
        }
    }, 1000);
}

$("startTest").addEventListener("click", () => {
    startTypingTest();
});

$("restartTest").addEventListener("click", () => {
    clearInterval(timerInterval);
    testRunning = false;
    activeLevel = null;

    $("typingInput").value = "";
    $("typingInput").disabled = true;
    $("startTest").disabled = false;
    $("startTest").textContent = "Start Test";

    prepareText(practiceTexts[0]);

    $("timer").textContent = data.testDuration;
    $("liveWpm").textContent = 0;
    $("liveAccuracy").textContent = 100;
    $("testResult").innerHTML = "";
});

$("typingInput").addEventListener("input", () => {
    if (!testRunning) return;

    const typed = $("typingInput").value;
    const spans = $("typingText").querySelectorAll("span");

    typedCharacters = typed.length;
    correctCharacters = 0;

    spans.forEach((span, index) => {
        span.classList.remove("correct", "incorrect", "current");

        if (index < typed.length) {
            if (typed[index] === currentText[index]) {
                span.classList.add("correct");
                correctCharacters++;
            } else {
                span.classList.add("incorrect");
            }
        } else if (index === typed.length) {
            span.classList.add("current");
        }
    });

    updateLiveStats();

    if (typed.length >= currentText.length) {
        finishTypingTest();
    }
});

function updateLiveStats() {
    if (!testRunning) return;

    const elapsed = Math.max(
        1,
        (Date.now() - startTime) / 60000
    );

    const wpm = Math.round(
        (correctCharacters / 5) / elapsed
    );

    const accuracy = typedCharacters
        ? Math.round(correctCharacters / typedCharacters * 100)
        : 100;

    $("liveWpm").textContent = wpm;
    $("liveAccuracy").textContent = accuracy;
}

function finishTypingTest() {
    if (!testRunning) return;

    clearInterval(timerInterval);
    testRunning = false;

    const elapsedSeconds = Math.max(
        1,
        (Date.now() - startTime) / 1000
    );

    const wpm = Math.round(
        (correctCharacters / 5) / (elapsedSeconds / 60)
    );

    const accuracy = typedCharacters
        ? Math.round(correctCharacters / typedCharacters * 100)
        : 0;

    const successful = wpm >= 5 && accuracy >= 70;

    const minutes = Math.max(
        0.1,
        elapsedSeconds / 60
    );

    const result = {
        wpm,
        accuracy,
        minutes,
        date: today(),
        timestamp: new Date().toLocaleString()
    };

    data.history.push(result);
    data.totalTests++;
    data.totalMinutes += minutes;
    data.bestWpm = Math.max(data.bestWpm, wpm);

    let levelMessage = "";

    if (activeLevel !== null && successful) {
        if (!data.completedLevels.includes(activeLevel)) {
            data.completedLevels.push(activeLevel);
        }

        levelMessage = "<p class='success'>🎉 Level " +
            activeLevel + " completed!</p>";
    } else if (activeLevel !== null) {
        levelMessage = "<p class='error'>Try again! You need at least 5 WPM and 70% accuracy to complete this level.</p>";
    }

    if (successful && !data.certificateUnlocked) {
        data.certificateUnlocked = true;

        showToast(
            "Congratulations! You have successfully completed your first TYPEPRO challenge. Your certificate is now unlocked!"
        );
    }

    saveData();

    $("typingInput").disabled = true;
    $("startTest").disabled = false;
    $("startTest").textContent = "Start New Test";

    $("testResult").innerHTML = `
        <h3>Practice Results 🎉</h3>
        <p>Typing Speed: <strong>${wpm} WPM</strong></p>
        <p>Accuracy: <strong>${accuracy}%</strong></p>
        <p>Correct Characters: <strong>${correctCharacters}</strong></p>
        <p>Time: <strong>${Math.round(elapsedSeconds)} seconds</strong></p>
        <p class="${successful ? "success" : "error"}">
            ${successful ? "Challenge Successful!" : "Keep practicing to improve!"}
        </p>
        ${levelMessage}
    `;

    if (activeLevel !== null && successful) {
        activeLevel = null;
    }

    renderAll();
}

/* =========================================
   100 LEVEL SYSTEM
========================================= */

function getLevelText(level) {
    const texts = [
        "asdf jkl;",
        "aaa sss ddd fff jjj kkk lll ;;;",
        "asdf jkl; asdf jkl;",
        "The quick brown fox jumps over the lazy dog.",
        "Practice every day to become a better typist.",
        "Good habits create excellent typing skills.",
        "Learning requires patience and daily practice.",
        "Technology helps people work faster and smarter.",
        "Accuracy is more important than typing speed.",
        "Professional typing begins with correct finger placement."
    ];

    if (level <= 10) return texts[level - 1];

    const templates = [
        "Typing improves with practice and patience. Keep your fingers relaxed and your eyes on the screen.",
        "A good typist uses the correct fingers and avoids unnecessary hand movements.",
        "Focus on accuracy first. Speed will improve as your keyboard skills become stronger.",
        "Students and professionals can benefit from developing excellent keyboard skills.",
        "Consistency is the secret to improving your typing performance."
    ];

    const template = templates[(level - 11) % templates.length];

    return Array(Math.ceil(level / 10))
        .fill(template)
        .join(" ");
}

function renderLevels() {
    const grid = $("levelsGrid");
    grid.innerHTML = "";

    const completed = getCompleted();

    $("levelSummary").textContent =
        `${completed} / 100 Completed`;

    $("levelProgress").style.width = completed + "%";

    for (let level = 1; level <= 100; level++) {
        const isCompleted = data.completedLevels.includes(level);
        const isUnlocked = level === 1 ||
            data.completedLevels.includes(level - 1);

        const card = document.createElement("article");

        card.className = "level-card" +
            (isCompleted ? " completed" : "") +
            (!isUnlocked ? " locked" : "");

        let status = isCompleted
            ? "✓ Completed"
            : isUnlocked
                ? "● Unlocked"
                : "🔒 Locked";

        card.innerHTML = `
            <small>LEVEL</small>
            <strong>${level}</strong>
            <div class="level-status">${status}</div>
            <button class="${isUnlocked ? "secondary-btn" : ""}"
                ${isUnlocked ? `data-start-level="${level}"` : "disabled"}>
                ${isCompleted ? "Replay" : isUnlocked ? "Start" : "Locked"}
            </button>
        `;

        grid.appendChild(card);
    }

    grid.querySelectorAll("[data-start-level]").forEach(button => {
        button.addEventListener("click", () => {
            const level = Number(button.dataset.startLevel);

            navigate("practice");
            startTypingTest(level);
        });
    });
}

/* =========================================
   PROGRESS TRACKER
========================================= */

function renderProgress() {
    $("totalTests").textContent = data.totalTests;
    $("progressWpm").textContent = data.bestWpm;
    $("progressAccuracy").textContent = getAverageAccuracy() + "%";

    $("practiceTime").textContent =
        Math.round(data.totalMinutes) + " min";

    const history = $("historyList");

    if (!data.history.length) {
        history.innerHTML =
            "<p class='muted'>No practice sessions yet. Start your first test!</p>";
        return;
    }

    history.innerHTML = data.history.slice(-10).reverse().map(item => `
        <div style="padding:13px 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
            <div><strong>${item.wpm} WPM</strong><p class="muted">${escapeHTML(item.timestamp || item.date)}</p></div>
            <div><strong>${item.accuracy}%</strong><p class="muted">Accuracy</p></div>
        </div>
    `).join("");
}

/* =========================================
   ACHIEVEMENTS
========================================= */

const achievements = [
    {
        name: "First Steps",
        icon: "🌱",
        description: "Complete your first level.",
        unlocked: () => getCompleted() >= 1
    },
    {
        name: "Typing Explorer",
        icon: "🧭",
        description: "Complete 5 levels.",
        unlocked: () => getCompleted() >= 5
    },
    {
        name: "Rising Star",
        icon: "⭐",
        description: "Complete 10 levels.",
        unlocked: () => getCompleted() >= 10
    },
    {
        name: "Typing Champion",
        icon: "🏆",
        description: "Complete 25 levels.",
        unlocked: () => getCompleted() >= 25
    },
    {
        name: "Halfway Hero",
        icon: "🥇",
        description: "Complete 50 levels.",
        unlocked: () => getCompleted() >= 50
    },
    {
        name: "Speed Starter",
        icon: "⚡",
        description: "Reach 30 WPM.",
        unlocked: () => data.bestWpm >= 30
    },
    {
        name: "Speed Master",
        icon: "🚀",
        description: "Reach 50 WPM.",
        unlocked: () => data.bestWpm >= 50
    },
    {
        name: "Accuracy Expert",
        icon: "🎯",
        description: "Achieve 95% accuracy in a test.",
        unlocked: () => data.history.some(x => x.accuracy >= 95)
    },
    {
        name: "Practice Lover",
        icon: "🔥",
        description: "Practice for 60 total minutes.",
        unlocked: () => data.totalMinutes >= 60
    },
    {
        name: "Perfect Start",
        icon: "💎",
        description: "Complete a test with 100% accuracy.",
        unlocked: () => data.history.some(x => x.accuracy === 100)
    },
    {
        name: "Dedicated Learner",
        icon: "📚",
        description: "Complete 75 levels.",
        unlocked: () => getCompleted() >= 75
    },
    {
        name: "TYPEPRO Legend",
        icon: "👑",
        description: "Complete all 100 levels.",
        unlocked: () => getCompleted() >= 100
    }
];

function renderAchievements() {
    const grid = $("achievementGrid");
    grid.innerHTML = "";

    achievements.forEach(achievement => {
        const unlocked = achievement.unlocked();

        const card = document.createElement("article");
        card.className = "panel achievement-card" +
            (!unlocked ? " locked" : "");

        card.innerHTML = `
            <div class="award">${achievement.icon}</div>
            <h3>${achievement.name}</h3>
            <p>${achievement.description}</p>
            <p style="margin-top:12px;font-weight:700">
                ${unlocked ? "✓ Unlocked" : "🔒 Locked"}
            </p>
        `;

        grid.appendChild(card);
    });
}

/* =========================================
   CERTIFICATES
========================================= */

function renderCertificates() {
    const unlocked = data.certificateUnlocked;

    $("certificateStatus").textContent = unlocked
        ? "🎉 Certificate Unlocked!"
        : "🔒 Certificate Locked";

    $("certificateDescription").textContent = unlocked
        ? "Congratulations! Your first challenge is complete. Generate your personalized certificate below."
        : "Complete your first successful typing challenge with at least 5 WPM and 70% accuracy to unlock your certificate.";

    $("certificateName").disabled = !unlocked;
    $("previewCertificate").disabled = !unlocked;
    $("downloadCertificate").disabled = !unlocked;
}

function generateCertificate() {
    if (!data.certificateUnlocked) {
        showToast("Complete your first challenge to unlock your certificate.");
        return false;
    }

    const name = $("certificateName").value.trim();

    if (name.length < 2) {
        showToast("Please enter your full name.");
        return false;
    }

    const preview = $("certificatePreview");

    preview.innerHTML = `
        <div class="eyebrow">TYPEPRO ACADEMY</div>
        <div class="seal">🏆</div>
        <h2>Certificate of Achievement</h2>
        <p>This certificate is proudly presented to</p>
        <h3>${escapeHTML(name)}</h3>
        <p>
            In recognition of successfully completing the first
            typing challenge at TYPEPRO — Typing Mastery & Professional
            Typing Academy.
        </p>
        <p style="margin-top:25px">
            Awarded on: ${new Date().toLocaleDateString()}
        </p>
        <div class="seal">⌨ TYPEPRO</div>
        <p>Learn Faster. Type Smarter. Become a Pro.</p>
    `;

    preview.classList.add("show");
    return true;
}

$("previewCertificate").addEventListener("click", () => {
    generateCertificate();
});

$("downloadCertificate").addEventListener("click", () => {
    if (!generateCertificate()) return;

    setTimeout(() => window.print(), 200);
});

/* =========================================
   PROFILE MANAGEMENT
========================================= */

$("saveProfile").addEventListener("click", () => {
    const name = $("profileName").value.trim();
    const age = Number($("profileAge").value);

    if (name.length < 2 || !Number.isInteger(age) || age < 1 || age > 120) {
        showToast("Please enter a valid name and age.");
        return;
    }

    data.profile = { name, age };
    saveData();

    $("greeting").textContent = "Welcome Back, " + name + "!";
    $("sidebarName").textContent = name;
    $("sidebarAvatar").textContent = name[0].toUpperCase();
    $("topAvatar").textContent = name[0].toUpperCase();
    $("profileAvatar").textContent = name[0].toUpperCase();

    $("profileMessage").textContent = "Profile updated successfully!";
    showToast("Profile saved!");
});

/* =========================================
   SETTINGS
========================================= */

function loadSettings() {
    $("dailyGoal").value = String(data.dailyGoal);
    $("testDuration").value = String(data.testDuration);
}

$("saveSettings").addEventListener("click", () => {
    data.dailyGoal = Number($("dailyGoal").value);
    data.testDuration = Number($("testDuration").value);

    saveData();

    $("settingsMessage").textContent =
        "Your preferences have been saved!";

    showToast("Settings updated successfully!");
});

$("clearProgress").addEventListener("click", () => {
    const confirmed = confirm(
        "Are you sure? This will reset your levels, achievements, certificates and practice history. Your profile will remain."
    );

    if (!confirmed) return;

    const profile = data.profile;

    data = {
        ...defaultData,
        profile,
        dailyGoal: 15,
        testDuration: 60
    };

    saveData();
    loadSettings();
    renderAll();

    showToast("Learning progress has been reset.");
});

$("resetProfile").addEventListener("click", () => {
    const confirmed = confirm(
        "Reset your entire TYPEPRO profile and all saved data?"
    );

    if (!confirmed) return;

    localStorage.removeItem(STORAGE_KEY);
    location.reload();
});

/* =========================================
   RENDER EVERYTHING
========================================= */

function renderAll() {
    renderDashboard();
    renderLessons();
    renderKeyboard();
    renderFingerButtons();
    renderVideos();
    renderLevels();
    renderProgress();
    renderAchievements();
    renderCertificates();
    loadSettings();
}

/* =========================================
   INITIALIZATION
========================================= */

initializeApp();
